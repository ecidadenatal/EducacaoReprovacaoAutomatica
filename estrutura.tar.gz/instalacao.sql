CREATE SEQUENCE plugins.formaavaliacaominimorecuperacao_sequencial_seq
INCREMENT 1
MINVALUE 1
MAXVALUE 9223372036854775807
START 1
CACHE 1;

CREATE TABLE plugins.formaavaliacaominimorecuperacao (sequencial integer  not null primary key ,
                                                formaavaliacao integer not null,
                                                minimorecuperacao numeric not null);

-- Vai se ligar com a tabela formaavaliacao (ed37_i_codigo)

CREATE SEQUENCE plugins.procresultadominimorecuperacao_sequencial_seq
INCREMENT 1
MINVALUE 1
MAXVALUE 9223372036854775807
START 1
CACHE 1;

CREATE TABLE plugins.procresultadominimorecuperacao (sequencial integer  not null primary key ,
                                                procresultado integer not null,
                                                minimorecuperacao numeric not null);

-- Vai se ligar com a tabela procresultado (ed43_i_codigo)

CREATE SEQUENCE plugins.diarioresultadoreprovado_sequencial_seq
INCREMENT 1
MINVALUE 1
MAXVALUE 9223372036854775807
START 1
CACHE 1;

CREATE TABLE plugins.diarioresultadoreprovado  (sequencial integer  not null primary key ,
                                                diarioresultado integer not null);

-- Vai se ligar com a tabela diarioresultado (ed73_i_codigo)
